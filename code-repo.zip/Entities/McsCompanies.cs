﻿using System;
using System.Collections.Generic;

namespace cms.Entities
{
    public partial class McsCompanies
    {
        public McsCompanies()
        {
            McsContactDetails = new HashSet<McsContactDetails>();
        }

        public string CompanyName { get; set; }
        public DateTime? ActivatedDate { get; set; }
        public DateTime DeactivatedDate { get; set; }
        public bool? Status { get; set; }
        public Guid CompanyId { get; set; }

        public ICollection<McsContactDetails> McsContactDetails { get; set; }
    }
}
