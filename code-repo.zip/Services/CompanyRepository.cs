﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cms.dtos;
using cms.Entities;
using cms.Models;
using cms.Services;
using Microsoft.EntityFrameworkCore;
namespace cms.Services
{
    public class CompanyRepository : ICompanyRepository, IDisposable
    {
        private MasterDBContext _context;
        public CompanyRepository(MasterDBContext context)
        {
            _context = context ??
                throw new ArgumentNullException(nameof(context));
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
        public virtual void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (_context != null)
                {
                    _context.Dispose();
                    _context = null;
                }
            }
        }

        public async Task<IEnumerable<McsCompanies>> GetCompanies()
        {
            return await _context.McsCompanies.Include(c => c.McsContactDetails).ToListAsync();

        }



        public async Task<McsCompanies> GetCompany(Guid companyId)
        {
            return await _context.McsCompanies.Include(c => c.McsContactDetails).FirstOrDefaultAsync(b => b.CompanyId == companyId);
        }
        public async Task AddCompany(McsCompanies company)
        {
            if (company == null)
            {
                throw new ArgumentNullException(nameof(company));
            }
            await _context.AddAsync(company);



        }
        public async Task<bool> SaveChanges()
        {
            return (await _context.SaveChangesAsync() > 0);
        }


    }
}