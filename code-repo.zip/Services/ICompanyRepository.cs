﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cms.dtos;

namespace cms.Services
{
    public interface ICompanyRepository
    {
        Task<IEnumerable<Entities.McsCompanies>> GetCompanies();
        Task<Entities.McsCompanies> GetCompany(Guid companyId);
        Task AddCompany(Entities.McsCompanies companies);
        Task<bool> SaveChanges();

    }
}
