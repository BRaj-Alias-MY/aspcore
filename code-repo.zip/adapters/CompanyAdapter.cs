using System;
using System.Collections.Generic;
using cms.dtos;

namespace cms.adapters
{
    public class CompanyAdapter
    {
        public dtos.CompanyDto ConvertEntityToDto(Entities.McsCompanies companies)
        {
            var companyDto = new CompanyDto();
            companyDto.CompanyId = companies.CompanyId;
            companyDto.CompanyName = companies.CompanyName;
            companyDto.ActivatedDate = companies.ActivatedDate;
            companyDto.DeactivatedDate = companies.DeactivatedDate;
            companyDto.Status = companies.Status;
            return companyDto;
        }
    }
}