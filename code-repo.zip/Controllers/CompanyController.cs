using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using cms.adapters;
using cms.dtos;
using cms.Models;
using cms.Services;
using Microsoft.AspNetCore.Mvc;
//using cms.Models;

namespace cms.Controllers
{
    [Route("api/[controller]")]
    public class CompanyController : ControllerBase
    {
        private ICompanyRepository _companyRepository;
        public CompanyController(ICompanyRepository companyRepository)
        {
            _companyRepository = companyRepository ??
                throw new ArgumentNullException(nameof(companyRepository));
        }

        [HttpGet]
        public async Task<IActionResult> GetCompanies()
        {
            var companyEntities = await _companyRepository.GetCompanies();
            if (companyEntities == null)
            {
                return NotFound();
            }

            return Ok(companyEntities);
        }
        [HttpGet]
        [Route("{id}")]
        public async Task<IActionResult> GetCompany(Guid id)
        {
            var companyEntity = await _companyRepository.GetCompany(id);
            if (companyEntity == null)
            {
                return NotFound();
            }
            return Ok(companyEntity);
        }
        [HttpGet]
        [Route("show")]
        public async Task<IActionResult> GetCompaniesList()
        {
            var companyEntity = await _companyRepository.GetCompanies();
            CompanyAdapter comp = new CompanyAdapter();
            List<object> data = new List<object>();
            object company = null;
            foreach (var e in companyEntity)
            {
                company = comp.ConvertEntityToDto(e);
                data.Add(company);
            }


            if (data == null)
            {
                return NotFound();
            }
            return Ok(data);
        }
        [HttpPost]
        public async Task<IActionResult> CreateBook([FromBody]Entities.McsCompanies company)
        {
            await _companyRepository.AddCompany(company);
            await _companyRepository.SaveChanges();


            return Ok(company);
        }
    }
}